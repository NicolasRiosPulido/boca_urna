import React from "react";

function ContenedorVotos(props) {
	return <div className="contenedorVotos">{props.children}</div>;
}

export default ContenedorVotos;
