import React from "react";

function ContenedorVotos(props) {
    return <div className="contenedorVotosNB">{props.children}</div>;
}

export default ContenedorVotos;