import React from "react";
import { Redirect } from 'react-router-dom';
import "../../css/numero.css";

import * as autenticacionReducer from "../../actions/autenticacionAction";
import { connect } from "react-redux";

import Modal from 'react-bootstrap/Modal';
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Titulo from "../general/Titulo";
import ContenedorCuerpo from "../general/ContenedorCuerpo";
import Spinner from "../general/Spinner";

const { getAutenticationCel } = autenticacionReducer;

class Codigo extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			modal: false
		}
	}
	manegoCambios = event => {
		let valor = event.currentTarget.value;
		let id = event.currentTarget.id;
		if (valor.length > 3) {
			event.preventDefault();
		}
	};
	SubmitHandler = async event => {
		event.preventDefault();
		const codigo = document.getElementById("codigo_a").value;
		await this.props.getAutenticationCel(codigo, this.props.autenticacionReducer.currentUser);

		if (this.props.autenticacionReducer.info.data.error === "101") {
			console.log("codigo no valido")
			this.setState({ modal: true })
		}
	};

	render() {
		if (this.props.autenticacionReducer.info.length !== 0) {
			if (this.props.autenticacionReducer.info.data.error === "") {
				return <Redirect from='/' to='/confirmar' />
			}
		}
		if (this.props.autenticacionReducer.cargando) {
			return <Spinner />
		}
		return (
			<React.Fragment>
				<Titulo tituloC="Ingrese el codigo de verificacion" />
				<ContenedorCuerpo>
					<Form onSubmit={this.SubmitHandler}>
						<div className="numeros">
							<Form.Group controlId="codigo_a" md="3">
								<Form.Control
									type="tel"
									required
									onKeyPress={this.manegoCambios}
									className="digitos"
									ref={elem => (this.textInput1 = elem)}
									pattern="[0-9]{0,5}"
								/>
							</Form.Group>
						</div>
						<Button
							variant="success"
							type="submit"
							size="lg"
							block
							style={{ marginTop: 15 }}
						>
							Ingresar
						</Button>
					</Form>
				</ContenedorCuerpo>
				<Modal
					size="lg"
					show={this.state.modal}
					onHide={() => this.setState({ modal: false })}
					aria-labelledby="example-modal-sizes-title-lg"
				>
					<Modal.Header closeButton>
						<Modal.Title id="example-modal-sizes-title-lg">
							<h2 >Error</h2>
						</Modal.Title>
					</Modal.Header>
					<Modal.Body>
						<h2 >Codigo invalido</h2>
					</Modal.Body>
					<Modal.Footer>
						<Button
							variant="warning"
							onClick={() => this.setState({ modal: false })}
						>
							Cerrar
						</Button>
					</Modal.Footer>
				</Modal>
			</React.Fragment>
		);
	}
}
const mapStateToProps = ({ autenticacionReducer }) => {
	return { autenticacionReducer };
};
const mapDispatchToProps = {
	getAutenticationCel
};
export default connect(
	mapStateToProps,
	mapDispatchToProps
)(Codigo);
