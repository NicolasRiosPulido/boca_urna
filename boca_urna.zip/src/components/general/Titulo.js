import React from "react";

function Titulo(props) {
	return (
		<React.Fragment>
			<h3 className="titulo">{props.tituloC}</h3>
		</React.Fragment>
	);
}

export default Titulo;
