import React from "react";

function ContenedorCuerpo(props) {
	return <div className="cuerpoContenedor">{props.children}</div>;
}

export default ContenedorCuerpo;
