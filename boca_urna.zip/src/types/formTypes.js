export const SET_MESA = "set_mesa";
export const ENVIAR_IMAGEN = "enviar_imagen";
export const ENVIAR_VOTOS = "enviar_votos";
export const CARGANDO = "cargando_form";
export const ERROR = "error_form";
