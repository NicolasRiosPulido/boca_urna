export const GET_AUTENTICACION = "get_autenticacion";
export const GET_AUTENTICACION_CEL = "get_autenticacion_cel";
export const CERRAR_CECION = "cerrar_secion_autentication";
export const CARGANDO = "cargando_autenticacion";
export const ERROR = "error_autenticacion";